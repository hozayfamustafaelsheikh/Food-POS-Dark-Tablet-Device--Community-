- Figma Design Source: https://www.figma.com/file/5mdb0IGeosmkR8z6Zrrz8p/Food-POS-Dark---Tablet-Device-(Community)?node-id=0%3A1&t=gB193wbL7H389SB3-0
- UI/UX Designer: yahyaamirudin (https://www.figma.com/@yahyaamirudin)
- Web Designer: Hozayfa Mustafa Elsheikh
- Created At: 12-Feb-2023

Languages and Technologies used:
- HTML
- CSS

Devices
- Desktop
- Tablet (Recommended)

Screenshots
![alt text](https://github.com/hozayfamustafaelsheikh/Food-POS-Dark-Tablet-Device--Community-/blob/main/assets/img/Screenshots/Firefox_Screenshot_2023-02-12T14-13-58.718Z.png?raw=true)

![alt text](https://github.com/hozayfamustafaelsheikh/Food-POS-Dark-Tablet-Device--Community-/blob/main/assets/img/Screenshots/Firefox_Screenshot_2023-02-13T13-08-07.343Z.png?raw=true)